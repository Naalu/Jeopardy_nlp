## code to prepare `jeopardy_data` dataset goes here

# This script reads the raw Jeopardy TSV data, performs minimal cleaning
# (consistent column names), and saves it as an internal .RData file
# for easy access within the package.

# Make sure the original TSV is in inst/extdata
# You might need to run install.packages("here") if you don't have it
# You might need to run install.packages("usethis") if you don't have it
# You might need to run install.packages("readr") if you don't have it
# You might need to run install.packages("janitor") if you don't have it
# Make sure your working directory is the package root when running this script.

library(readr)
library(janitor)
library(usethis)
library(here) # To robustly locate the file relative to project root

# Define path relative to project root
raw_data_path <- here::here("inst", "extdata", "master_season1-35.tsv")

# Check if file exists
if (!file.exists(raw_data_path)) {
    stop(
        "Raw data file not found at: ", raw_data_path,
        "\nPlease ensure master_season1-35.tsv is in the inst/extdata directory."
    )
}

# Read the raw TSV data
raw_data <- readr::read_tsv(
    raw_data_path,
    col_types = readr::cols(.default = "c"), # Read all as character initially
    show_col_types = FALSE,
    name_repair = janitor::make_clean_names # Clean names immediately
)

# Assign to the desired object name for the package
jeopardy_data <- raw_data

#' Jeopardy Questions Dataset (Raw, Cleaned Names)
#'
#' A dataset containing questions and answers from the TV show Jeopardy!
#' This dataset includes information about the show number, air date, round,
#' category, value, question, and answer. Column names have been cleaned
#' using `janitor::make_clean_names`.
#'
#' @format A tibble (data frame) with approximately 216,930 rows and 7 columns:
#' \describe{
#'   \item{show_number}{The unique number identifying the show.}
#'   \item{air_date}{The date the show originally aired.}
#'   \item{round}{The round of the game (e.g., "Jeopardy!", "Double Jeopardy!", "Final Jeopardy!").}
#'   \item{category}{The category of the clue.}
#'   \item{value}{The dollar value of the clue. Character format (e.g., "$200").}
#'   \item{question}{The text of the clue.}
#'   \item{answer}{The text of the answer.}
#'   # Add other relevant columns if read_tsv reads more by default
#'   # \item{notes}{}
#'   # \item{daily_double}{}
#' }
#' @source Based on data aggregated by Reddit user u/jwolle1 and shared at \url{https://www.reddit.com/r/datasets/comments/cj3ipd/jeopardy_dataset_with_349000_clues/}. Also available at Kaggle \url{https://www.kaggle.com/datasets/prondeau/350000-jeopardy-questions?select=master_season1-35.tsv}.
"jeopardy_data"


# Save the cleaned data frame to the data/ directory
# This makes `jeopardy_data` available directly when the package is loaded.
usethis::use_data(jeopardy_data, overwrite = TRUE)

# Optional: Compress further if needed (might save space)
# usethis::use_data(jeopardy_data, overwrite = TRUE, compress = "xz")

message("data/jeopardy_data.RData created successfully.")
message("Remember to run devtools::document() to generate the documentation.")
