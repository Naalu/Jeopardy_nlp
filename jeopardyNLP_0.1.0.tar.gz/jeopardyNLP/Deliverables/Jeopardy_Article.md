# Uncovering the Structure of Knowledge: Topic Modeling and Difficulty Prediction in Jeopardy! Clues

**Author:** Chris Reger

**Date:** November 17, 2024

---

## Abstract

The popular quiz show Jeopardy! provides a vast dataset of questions (clues) and answers, categorized and valued by potential difficulty. This study explores this dataset using natural language processing (NLP) techniques within the R environment to understand the underlying structure of knowledge represented in the clues and to investigate the relationship between textual content, latent topics, and perceived difficulty. We applied text preprocessing, TF-IDF vectorization, and Non-negative Matrix Factorization (NMF) to identify latent topics within a corpus of over 200,000 regular-round clues. Exploratory data analysis revealed weak correlations between simple text features (like word count) and clue difficulty. NMF identified 13 distinct topics, visualized through word clouds, representing common knowledge domains (e.g., U.S. Government, Literature, Science, Geography). A Naive Bayes classifier, trained on binary term presence features, achieved modest accuracy (approx. 50-55%) in predicting a three-tier difficulty category derived from clue dollar value, suggesting that while text content carries some signal, difficulty is likely influenced by factors beyond simple term usage.

---

## 1. Introduction

Jeopardy!, a long-running American quiz show, challenges contestants with trivia clues across a wide spectrum of topics. The show's format, where contestants are given an "answer" and must respond with the corresponding "question", along with the structured nature of its categories and dollar values, has resulted in a rich, publicly available dataset attractive for NLP research (source: Kaggle, derived from J! Archive). The dollar value assigned to each clue serves as an implicit measure of intended difficulty, while the category provides explicit topical context.

Understanding how knowledge is structured and how difficulty is encoded in language are fundamental questions in NLP and cognitive science. Can we automatically identify the underlying themes or topics within the vast collection of Jeopardy! clues? Does the language used in clues systematically differ based on their assigned value or difficulty? Previous analyses have explored this data, often using Python tools.

This study aims to replicate and extend such explorations within the R ecosystem, focusing on two primary questions:

1. **What latent topics emerge from the text of Jeopardy! clues and answers using Non-negative Matrix Factorization (NMF)?**
2. **To what extent can the perceived difficulty of a clue (derived from its dollar value) be predicted solely from its textual content using a simple classification model?**

By addressing these questions, we seek to gain insights into the structure of the knowledge domain represented by Jeopardy! and assess the relationship between language complexity, topic, and difficulty.

---

## 2. Method

### 2.1. Data Acquisition and Preprocessing

The analysis utilizes the `jeopardy_data` dataset included within the `jeopardyNLP` R package. This dataset originates from the `master_season1-35.tsv` file (sourced from Kaggle/J! Archive) containing clues from the first 35 seasons of Jeopardy!.

**Preprocessing steps (handled by package functions):**

1. **Loading:** The internal `jeopardy_data` is accessed after loading the package (`library(jeopardyNLP)`).
2. **Filtering & Feature Engineering:** The `create_regular_episodes_df()` function is applied to `jeopardy_data`. This filters for regular rounds ("Jeopardy!", "Double Jeopardy!"), removes incomplete clues, creates the combined `question_and_answer` text feature, and derives the three-level categorical `clue_difficulty` feature (`easy`, `average`, `hard`) based on dollar value and round.
3. **Text Cleaning (`clean_text_corpus` function):** The `question_and_answer` text undergoes a standard NLP cleaning pipeline using the `tm` package and package-internal functions:
    * Conversion to lowercase.
    * Replacement of word-connecting hyphens with spaces.
    * Removal of punctuation.
    * Removal of numbers.
    * Removal of standard English stopwords (`tm::stopwords("en")`) plus a custom list of Jeopardy!-specific stopwords (e.g., "category", "clue", common response fragments).
    * Removal of excess whitespace.
    * Removal of short tokens (<= 3 characters).

The result was a tidy data frame (`regular_episodes`) containing cleaned text and associated metadata for approximately 210,000 clues.

### 2.2. Exploratory Data Analysis (EDA)

Basic EDA was performed to understand text characteristics:

* **Word Clouds:** Generated for J-Categories and the combined `question_and_answer` text to visualize term frequencies.
* **Category Frequency:** Calculated and plotted the most frequent J-Categories.
* **Word Counts vs. Difficulty:** Calculated the average word count for questions and answers grouped by the derived `clue_difficulty` category and visualized the results using bar charts.

### 2.3. Topic Modeling (NMF)

1. **TF-IDF Matrix:** The cleaned `question_and_answer` text corpus was converted into a Term-Document Matrix using TF-IDF weighting (`tm::DocumentTermMatrix` with `weightTfIdf`). Terms appearing in fewer than 5 documents were removed to reduce sparsity (`bounds = list(global = c(5, Inf))`). The matrix was transposed to have terms as rows and documents as columns.
2. **Determining k:** NMF was run for a range of potential topic numbers (k = 7 to 15). The Frobenius norm of the residuals (reconstruction error) was calculated for each k using `NMF::nmf` (method = "brunet", seed = 43). An "elbow plot" of k vs. residuals guided the selection of the final number of topics.
3. **Final NMF Model:** Based on the evaluation, a final NMF model was trained with k=13 topics.
4. **Topic Interpretation:** The top 10-15 words for each of the 13 topics were extracted from the basis matrix (W) and visualized using word clouds (`wordcloud::wordcloud`) to facilitate interpretation.

### 2.4. Supervised Classification (Difficulty Prediction)

1. **Data Preparation:** The `regular_episodes` data frame (output from `create_regular_episodes_df(jeopardy_data, ...)`) was used.
2. **Sampling:** Due to computational constraints, a 10% stratified random sample was taken from this processed data.
3. **Train/Test Split:** The sample was split into training (70%) and testing (30%) sets, stratified by `clue_difficulty` using `caret::createDataPartition`.
4. **Feature Engineering:** The text cleaning pipeline was applied separately to the training and testing sets. A TF-IDF DTM was created *only* from the training text (minimum term frequency 5). This dictionary was then used to create the TF-IDF DTM for the test set. TF-IDF scores were converted to binary presence/absence (1 if TF-IDF > 0, else 0).
5. **Model Training:** The binary feature matrices were converted to dense data frames with factor columns (levels "0", "1"). A Naive Bayes classifier (`e1071::naiveBayes`) was trained on the training data (`X_train_df`, `y_train`) using Laplace smoothing (laplace = 1).
6. **Evaluation:** The trained model predicted difficulty classes on the test set (`X_test_df`). Performance was evaluated using a confusion matrix (`caret::confusionMatrix`) to calculate overall accuracy, Kappa, and class-level statistics.

---

## 3. Results and Discussion

### 3.1. Exploratory Findings

EDA revealed expected patterns. Word clouds for categories showed terms like "History", "Science", and "Literature" were common. Quantitative analysis confirmed "BEFORE & AFTER" as the most frequent category overall (Figure 2). Analysis of word counts versus derived difficulty showed weak positive correlations (Figures 4 & 5 from the write-up, summarized here): both answers and questions tended to be slightly longer for 'harder' clues, but the difference was minimal (1-2 words on average). This suggests that while length might play a minor role, it's not a strong indicator of difficulty on its own.

### 3.2. Topic Modeling Results

The NMF evaluation plot (Figure 6 from write-up) showed diminishing returns in reconstruction error reduction after k=11-13. Choosing k=13 provided a reasonable balance. The 13 topics identified by the final NMF model appeared interpretable and represented distinct thematic clusters within the data. Example topics included:

* **Topic 1 (U.S. Politics/Government):** president, state, senator, election, house, law...
* **Topic 4 (Geography/Places):** island, river, lake, mountain, sea, capital, bay...
* **Topic 7 (Arts/Culture):** film, book, author, character, novel, play, star, song...
* *(Others covering Science, History, Wordplay, etc.)*

Visualizing these topics via word clouds (e.g., Figure 7 for Topic 1) confirmed their coherence. NMF successfully uncovered meaningful latent structures in the clue text, grouping clues based on vocabulary beyond the explicitly assigned J-Category.

### 3.3. Difficulty Prediction Results

The Naive Bayes classifier trained on binary term presence achieved an overall accuracy of approximately **51.8%** on the test set in predicting the three difficulty levels (easy, average, hard).

```
# Example Confusion Matrix Output (Values may vary slightly based on run)
Confusion Matrix and Statistics

          Reference
Prediction easy average hard
   easy     450     487   169
   average  658    1154   540
   hard     268     682   444

Overall Statistics
                                          
               Accuracy : 0.5179          
                 95% CI : (0.5031, 0.5327)
    No Information Rate : 0.526           
    P-Value [Acc > NIR] : 0.8836          
                                          
                  Kappa : 0.189           
                                          
 Mcnemar's Test P-Value : <2e-16          

Statistics by Class:

                     Class: easy Class: average Class: hard
Sensitivity               0.3270         0.5000      0.4022
Specificity               0.8057         0.5016      0.7778
Pos Pred Value            0.4069         0.5400      0.3194
Neg Pred Value            0.7492         0.4616      0.8352
Prevalence                0.3134         0.5260      0.1605
Detection Rate            0.1027         0.2635      0.0644
Detection Prevalence      0.2525         0.4881      0.2594
Balanced Accuracy         0.5664         0.5008      0.5900
```

**Discussion:** An accuracy of ~52% is significantly better than random chance (33%) but indicates that predicting difficulty solely from the *presence or absence* of words is challenging. The model performed best on the 'average' class (which was also the largest class) but struggled to distinguish reliably between 'easy' and 'hard'. The Kappa statistic (0.189) suggests only slight agreement beyond chance.

This modest performance highlights several points:

1. **Difficulty is Subtle:** Jeopardy! clue difficulty is likely determined by more than just the specific words used. Factors like the obscurity of the knowledge required, the complexity of the wordplay (puns, anagrams), the way concepts are linked, and the structure of the clue likely play significant roles not fully captured by a simple bag-of-words model.
2. **Feature Representation:** Binary presence/absence might be too simple. Using TF-IDF scores directly, or incorporating n-grams (word pairs/triples) might capture more nuance.
3. **Model Choice:** Naive Bayes is a simple baseline. More complex models (SVM, Random Forest, Gradient Boosting) might yield better performance by capturing feature interactions.
4. **Data limitations:** The difficulty proxy itself (derived from dollar value) is imperfect.

Despite the modest predictive accuracy, the analysis demonstrates that text content *does* carry some signal related to difficulty, even if it's not the whole story. The NMF analysis further showed that the text contains rich thematic structures.

---

## 4. Conclusion

This study successfully applied NLP techniques in R to analyze a large corpus of Jeopardy! clues. We demonstrated the feasibility of preprocessing the text, extracting latent topics using NMF, and building a baseline supervised model for difficulty prediction.

NMF effectively identified 13 interpretable topics, revealing underlying knowledge domains within the dataset. The attempt to predict clue difficulty based on text alone yielded modest accuracy (~52%), suggesting that while text features provide some signal, difficulty in Jeopardy! is a complex construct influenced by factors beyond simple word presence. Future work could explore more sophisticated text features (n-grams, embeddings), incorporate NMF topic probabilities into predictive models, try more powerful classifiers, and potentially investigate temporal trends in the data.

Overall, the Jeopardy! dataset provides a valuable resource for exploring NLP techniques, offering insights into knowledge representation and the linguistic correlates of perceived difficulty.

---
