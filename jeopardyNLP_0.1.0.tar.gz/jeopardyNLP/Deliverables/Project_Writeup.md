# Jeopardy! NLP Project Write-up

## 1. Introduction

### Why did you choose this data for analysis?

The Jeopardy! dataset, encompassing decades of clues, answers, categories, and values, presents a rich and structured source of text data tied to specific knowledge domains and perceived difficulty (value). This provides a unique opportunity to explore natural language processing (NLP) techniques beyond simple text classification. It allows for investigating relationships between language complexity, topic modeling, and categorical information in a familiar and engaging context. The dataset's origin from a popular, long-running television show adds an element of cultural relevance and inherent interest.

### What did you hope to learn?

The primary goal was to apply and evaluate various NLP techniques within an R environment, translating a previous Python-based analysis. Specifically, we aimed to:

1. **Master Data Preprocessing in R:** Implement robust text cleaning and feature engineering pipelines (like TF-IDF) using R's `tm` package and related tools.
2. **Explore Text Characteristics:** Understand the linguistic features of Jeopardy! clues, such as word frequency, clue length, and how these relate to categories and difficulty.
3. **Discover Latent Topics:** Utilize unsupervised learning (NMF) to uncover underlying themes or "meta-categories" within the combined question and answer text, potentially revealing structures not explicitly defined by the J-Category labels.
4. **Predict Clue Difficulty:** Build a supervised model to predict the assigned difficulty level ('easy', 'average', 'hard') based purely on the text content, assessing the extent to which language complexity signals difficulty.
5. **Develop an R Package:** Structure the analysis code into a reusable R package, adhering to best practices for documentation, file organization, and dependency management.

### What is important/interesting about the data?

* **Longevity and Size:** The dataset spans over 35 seasons, offering a large corpus of text reflecting evolving language and knowledge over time (although this analysis focused on the aggregated data).
* **Structured Metadata:** Each clue is associated with valuable metadata: category, air date, season, round, and dollar value. This allows for multifaceted analysis linking text content to external factors.
* **Implicit Difficulty:** The dollar value provides a proxy for intended difficulty, enabling supervised learning tasks related to text complexity.
* **Diverse Topics:** The J-Categories cover a vast range of human knowledge, making it a challenging and comprehensive dataset for topic modeling.
* **Question/Answer Format:** The unique format where the "answer" is presented as a question provides interesting NLP challenges. Combining question and answer text, as done in this project, captures the core information unit.

### How confident do you feel in the source of the data?

The data is sourced from Kaggle, originating from the "J! Archive" website (j-archive.com), a fan-maintained site known for its meticulous record-keeping of Jeopardy! episodes. While not an official source directly from the show's producers, the J! Archive is widely regarded by the Jeopardy! community as highly accurate and comprehensive. Minor inconsistencies or transcription errors are possible, as with any large, manually curated dataset, but the overall confidence in the data's authenticity and general accuracy is high for the purposes of this NLP analysis. The clear structure (TSV format) also adds to its usability.

---

## 2. Data Cleaning

### What was necessary to get the data properly cleaned?

Several steps were crucial for preparing the data for NLP analysis:

1. **Loading:** The package includes a pre-processed dataset `jeopardy_data` derived from the raw `master_season1-35.tsv`. Users load the package (`library(jeopardyNLP)`) to access this data.
2. **Filtering & Processing:** The function `create_regular_episodes_df` is used on `jeopardy_data` to filter for regular rounds (Jeopardy, Double Jeopardy), remove clues with missing essential info, and standardize column names.
3. **Feature Engineering:** The `create_regular_episodes_df` function also:
    * **Combined Text:** Creating a new column (`Question And Answer`) by concatenating the `Question` and `Answer` fields to form the primary text corpus for analysis.
    * **Clue Difficulty:** Deriving a categorical difficulty level (`easy`, `average`, `hard`) based on the dollar value within each round, accounting for the doubling of values in Double Jeopardy.
4. **Text Preprocessing (using `tm` and custom functions):**
    * **Lowercasing:** Converting all text to lowercase.
    * **Hyphen Handling:** Replacing hyphens between words with spaces (e.g., "state-of-the-art" -> "state of the art").
    * **Punctuation Removal:** Removing punctuation marks.
    * **Number Removal:** Removing digits.
    * **Stopword Removal:** Removing common English stopwords (using `tm`'s list) and custom stopwords relevant to Jeopardy! (e.g., "this", "category", clue fragments found in `stopwords.txt`).
    * **Whitespace Stripping:** Removing excess whitespace.
    * **(Optional) Short Token Removal:** Removing words shorter than a specified length (e.g., <= 3 characters) after the main cleaning steps.
    * **(Optional) Stemming/Lemmatization:** While explored, stemming and lemmatization were optional steps not applied by default in the final cleaning function for the main analyses but available via function arguments.

### What challenges did you encounter while cleaning?

* **Defining "Difficulty":** Mapping dollar values to discrete difficulty categories required careful consideration of the different rounds and the doubling of values. The chosen heuristic (tertiles within rounds) is reasonable but inherently an approximation of true difficulty.
* **Stopword Selection:** Identifying appropriate custom stopwords required some iteration. The custom list is included in `inst/extdata/stopwords.txt` and loaded by `clean_text_corpus`.
* **Text Cleaning Order:** The order of operations in text cleaning matters (e.g., removing punctuation before or after splitting hyphens). The chosen order aimed for logical consistency.
* **Efficiency:** Processing the full dataset can be time-consuming, especially during text cleaning and TF-IDF matrix creation. Sampling was used in the supervised learning vignette for practicality.
* **Package Dependencies:** Ensuring all necessary packages (`tm`, `dplyr`, `NMF`, etc.) were listed in the `DESCRIPTION` file.
* **Data Packaging:** Refactoring the workflow to include processed data (`jeopardy_data`) within the package itself, ensuring raw data and stopwords were correctly placed in `inst/extdata`, and updating functions to use the internal data by default.

### A short description of key variables in the dataset

*(Focusing on the structure returned by `create_regular_episodes_df(jeopardy_data)`)*

* `show_number`: Identifier for the specific Jeopardy! episode.
* `air_date`: Date the episode originally aired.
* `round`: The round the clue appeared in (either "Jeopardy!" or "Double Jeopardy!").
* `category`: The J-Category the clue belonged to.
* `value`: The dollar value of the clue (character format, e.g., "$200").
* `question`: The text of the clue presented to contestants.
* `answer`: The correct response (phrased as a question).
* `question_and_answer`: Combined text of `question` and `answer`, used as the primary input for NLP models.
* `clue_difficulty`: Categorical variable (`easy`, `average`, `hard`) derived from `value` and `round`. This is the target variable for supervised learning.

### A data table presenting an abbreviated tidy data set

Here's a conceptual representation of the first few rows of the tidy data frame resulting from `create_regular_episodes_df(jeopardy_data)` (actual content will vary):

| show_number | air_date   | round           | category            | value | question                         | answer           | question_and_answer                    | clue_difficulty |
| :---------- | :--------- | :-------------- | :------------------ | :---- | :------------------------------- | :--------------- | :------------------------------------- | :-------------- |
| 4680        | 2004-12-31 | Jeopardy!       | HISTORY             | $200  | For the last 8 years of his... | Who is Truman?   | For the last 8 years of his...Who is Truman? | easy            |
| 4680        | 2004-12-31 | Jeopardy!       | ESPIONAGE           | $200  | In 196 espionage...          | What is a U-2?   | In 196 espionage...What is a U-2?    | easy            |
| 4680        | 2004-12-31 | Double Jeopardy! | LITERATURE          | $800  | This title character asks...   | Who is Pip?      | This title character asks...Who is Pip?  | average         |
| 4680        | 2004-12-31 | Double Jeopardy! | SCIENCE             | $1200 | It's the colorful geologic...  | What is Cenozoic?| It's the colorful geologic...What is Cenozoic? | hard            |
| 4681        | 2005-01-03 | Jeopardy!       | AMERICAN AUTHORS    | $400  | He wrote "The Ambassadors"...  | Who is Henry James? | He wrote "The Ambassadors"...Who is Henry James? | average         |

*(This table uses placeholder text for brevity)*

---

## 3. Data Visualizations

*(Note: In a standard report, each figure would start on a new page. Here, we use horizontal rules and clear headers for separation.)*

---

### Figure 1: Word Cloud of J-Categories

![J-Category Word Cloud](./images/eda_images/J_Category_wordcloud.png)

**Figure 1 Caption:** A word cloud visualizing the frequency of words appearing in the 'J-Category' column of the dataset. Larger words appear more frequently. Basic text cleaning (lowercasing, punctuation removal, stopword removal) was applied internally by the plotting function for this visualization.

**Description:** This word cloud provides a quick visual summary of the most common terms used in Jeopardy! category titles. We can see expected high-frequency terms like "History", "Science", "Literature", "American", "World", and "Before & After" (appearing as separate words "before", "after" due to cleaning). This confirms the broad range of topics covered in the show and highlights recurring themes in category naming conventions. It helps orient us to the types of knowledge domains present in the dataset.

---

### Figure 2: Top 10 Most Common J-Categories by Estimated Episode Appearance

![Top 10 Categories Bar Chart](./images/eda_images/top_categories_bar.png)

**Figure 2 Caption:** A horizontal bar chart showing the top 10 most frequent J-Categories, based on the estimated number of episodes they appeared in (calculated as raw clue count divided by 5).

**Description:** This plot quantifies the insights from the category word cloud. "BEFORE & AFTER" is clearly the most frequent category by a significant margin, appearing in an estimated ~400 episodes. Other common categories include "SCIENCE", "LITERATURE", "AMERICAN HISTORY", "POTPOURRI", "WORLD HISTORY", "WORD ORIGINS", "COLLEGES & UNIVERSITIES", "HISTORY", and "SPORTS". This confirms the prevalence of certain broad topics and recurring "meta-categories" like "BEFORE & AFTER" and "POTPOURRI". The horizontal orientation aids readability of the category names.

---

### Figure 3: Word Cloud of Combined Question and Answer Text

![Question & Answer Word Cloud](./images/eda_images/Question_And_Answer_wordcloud.png)

**Figure 3 Caption:** A word cloud visualizing the frequency of words appearing in the combined 'Question And Answer' text column after basic cleaning (lowercasing, punctuation removal, stopword removal).

**Description:** This visualization shifts focus from category names to the actual content of the clues and answers. We see many common English words ("one", "two", "first", "named", "called", "like"), but also terms indicative of Jeopardy! content, such as "king", "president", "city", "state", "John", "George", "French", "War". This gives a sense of the typical vocabulary encountered in the clues, though it's heavily influenced by high-frequency, less discriminative words. More advanced techniques like TF-IDF are needed to identify terms truly characteristic of specific topics or difficulty levels.

---

### Figure 4: Average Answer Word Count vs. Clue Difficulty

![Answer Word Count Bar Chart](./images/eda_images/Answer_Word_Count_counts_bar.png)

**Figure 4 Caption:** A bar chart comparing the average number of words in the 'Answer' field across the three derived 'Clue Difficulty' categories (easy, average, hard).

**Description:** This plot investigates a potential relationship between answer length and perceived difficulty. It shows a slight trend: 'easy' clues have the shortest average answers (around 2.1 words), while 'average' and 'hard' clues have slightly longer answers (around 2.3-2.4 words). While the difference is small, it suggests that harder clues might sometimes require slightly longer or more specific answers. However, the overlap is considerable, indicating answer length alone is a weak predictor of difficulty.

---

### Figure 5: Average Question Word Count vs. Clue Difficulty

![Question Word Count Bar Chart](./images/eda_images/Question_Word_Count_counts_bar.png)

**Figure 5 Caption:** A bar chart comparing the average number of words in the 'Question' field (the clue text) across the three derived 'Clue Difficulty' categories (easy, average, hard).

**Description:** Similar to Figure 4, this plot examines the relationship between clue length (question text) and difficulty. Here, the trend is slightly more pronounced. 'Easy' questions have an average length of about 13 words, 'average' questions around 14 words, and 'hard' questions approach 15 words. This aligns with the intuition that more difficult clues might require more complex phrasing, more context, or more subordinate clauses, leading to slightly longer questions. Still, the differences are relatively small, reinforcing that simple word count is not a strong differentiator of difficulty on its own.

---

### Figure 6: NMF Topic Model Evaluation (k vs. Residuals)

![NMF k Evaluation Plot](./images/results_images/reconerr_vs_k.png)

**Figure 6 Caption:** A line plot showing the Frobenius norm of the residuals (reconstruction error) for NMF models trained with different numbers of topics (k), ranging from 7 to 15.

**Description:** This plot helps determine an appropriate number of topics for the NMF topic modeling. The goal is often to find the "elbow point" where the residuals decrease sharply and then start to level off, indicating diminishing returns from adding more topics. In this plot, the residuals decrease consistently, but the rate of decrease appears to slow somewhat around k=11 to k=13. Based on this visual inspection and alignment with the original project's findings, k=13 was selected as a reasonable number of topics for the final NMF model, balancing model fit (lower residuals) and potential topic interpretability (avoiding excessive, potentially overlapping topics).

---

### Figure 7: Example NMF Topic Word Cloud (Topic 1)

![NMF Topic 1 Word Cloud](./images/results_images/topic_1_wordcloud.png)

**Figure 7 Caption:** A word cloud visualization of the top 15 most heavily weighted words for Topic 1, as identified by the NMF model trained with k=13 topics. Word size is proportional to the term's weight within the topic.

**Description:** This word cloud represents one of the 13 latent topics discovered by NMF. Topic 1 appears strongly related to **U.S. Government and Politics**, with prominent terms like "president", "state", "senator", "election", "house", "law", "court", "federal", "bill", and "vice". Visualizing the top words for each topic helps in interpreting the underlying themes captured by the unsupervised model. Examining all 13 topic clouds (as done in the `unsupervised-model-explorations.Rmd` vignette) provides a holistic view of the thematic structure NMF found within the Jeopardy! clue text.

---

## 4. Conclusions

### If given more time, what other statistical or exploratory analysis might you have done?

* **Temporal Analysis:** Explore how categories, clue difficulty, or topics change over the 35+ seasons. Are there trends in language complexity or popular subjects?
* **N-grams:** Analyze bi-grams and tri-grams (sequences of 2-3 words) in addition to single words (unigrams) during TF-IDF creation. This might capture more contextual information.
* **Advanced Topic Modeling:** Experiment with other topic modeling techniques like Latent Dirichlet Allocation (LDA) or compare different NMF algorithms and initialization methods available in the `NMF` package. Evaluate topics using coherence scores in addition to residuals.
* **Feature Engineering for Supervised:** Incorporate NMF topic probabilities as features in the supervised difficulty prediction model. Include non-text features like category or round.
* **Different Supervised Models:** Train and compare other classifiers beyond Naive Bayes (e.g., SVM with linear or radial basis function kernels, Logistic Regression with regularization via `glmnet`, Random Forest, Gradient Boosting using `xgboost`). Implement proper hyperparameter tuning using cross-validation (e.g., with `caret` or `tidymodels`).
* **Error Analysis:** Deeply analyze the misclassifications made by the supervised model. Are certain types of clues or difficulties harder to predict?
* **Category Network Analysis:** Explore relationships between categories. Do certain categories frequently appear together?

### If interested, attempt a statistical or additional exploratory analysis

*(Example addition: Basic Category Length Analysis)*

One simple additional exploration is to examine the distribution of J-Category name lengths.

```R
# Assuming 'regular_episodes' dataframe is available
library(dplyr)
library(ggplot2)

category_lengths <- regular_episodes %>%
  distinct(category) %>%
  mutate(cat_length = nchar(category))

ggplot(category_lengths, aes(x = cat_length)) +
  geom_histogram(binwidth = 5, fill = "skyblue", color = "black") +
  labs(title = "Distribution of J-Category Name Lengths",
       x = "Number of Characters in Category Name",
       y = "Frequency (Number of Unique Categories)") +
  theme_minimal()

summary(category_lengths$cat_length)
```

This analysis might reveal typical lengths for category names and identify outliers (very short or very long names), potentially offering minor insights into how categories are constructed. The summary statistics show the minimum, maximum, median, and mean lengths.

### What did you learn if you used this data in a previous project?

This project involved translating a previous Python analysis into R. Key learnings from this process include:

* **Package Equivalents:** Identifying and utilizing the R equivalents for Python libraries (e.g., `tm` for `sklearn.feature_extraction.text`, `NMF` for `sklearn.decomposition.NMF`, `dplyr` for `pandas`, `ggplot2` for `matplotlib`/`seaborn`, `caret` for aspects of `sklearn.model_selection` and `sklearn.metrics`).
* **Workflow Differences:** Adapting to slightly different function arguments, data structures (sparse matrices from `tm` vs. `scipy`), and common workflow patterns between the two languages/ecosystems.
* **R Package Structure:** Gaining practical experience in organizing code and documentation into a standard R package structure using `roxygen2` for documentation and standard directories (`R/`, `man/`, `vignettes/`, `inst/`).
* **Reproducibility:** Reinforcing the importance of setting seeds, managing dependencies (`DESCRIPTION` file), and clear documentation (vignettes) for ensuring the analysis can be reproduced.
* **Strengths of R:** Appreciating the strengths of R's statistical modeling heritage, the ease of generating high-quality plots with `ggplot2`, and the robust framework for package development and documentation.

### What challenges in analysis would you foresee?

* **Scalability:** Applying complex models or extensive hyperparameter searches to the *full* dataset (millions of clues) would require significant computational resources and potentially techniques for handling larger-than-memory data or distributed computing.
* **Topic Interpretability:** While NMF provides topics, rigorously interpreting and validating their meaning can be subjective and time-consuming.
* **Defining "Difficulty":** The proxy for difficulty based on dollar value is imperfect. True cognitive difficulty is complex and multi-faceted. Building a model that truly captures nuanced difficulty would be very challenging.
* **Temporal Drift:** Language and topics evolve. Models trained on the entire dataset might not perform optimally on specific eras. Accounting for temporal drift would add complexity.
* **Feature Engineering:** Moving beyond TF-IDF to more sophisticated features (e.g., embeddings, linguistic features) could improve model performance but requires deeper NLP expertise and potentially more complex pipelines.

---

## 5. Link to GitHub Repository

[Link to your GitHub repository URL here](https://github.com/Naalu/Jeopardy_nlp)

*(Remember to replace the placeholder link above with the actual URL to your GitHub repository containing this project.)*
