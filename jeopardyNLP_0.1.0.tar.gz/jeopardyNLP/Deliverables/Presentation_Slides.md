# Jeopardy! NLP Analysis: Topics & Difficulty

**Presenter:** Chris Reger

---

## Slide 1: Title Slide

* **Uncovering the Structure of Knowledge: Topic Modeling and Difficulty Prediction in Jeopardy! Clues**
* Chris Reger
* [Date]

---

## Slide 2: Introduction & Research Questions

* **Context:** Jeopardy! dataset (Kaggle/J! Archive) - rich source of categorized, valued trivia clues.
* **Goal:** Apply NLP in R to understand knowledge structure and text-based difficulty signals.
* **Tool:** `jeopardyNLP` R Package developed for this analysis.
* **Research Questions:**
    1. What latent topics emerge from clue text using NMF?
    2. How well can clue difficulty (easy/average/hard) be predicted from text alone?

---

## Slide 3: Methods Overview

1. **Data:** Internal `jeopardy_data` object in `jeopardyNLP` package (~210k regular clues).
2. **Preprocessing (using package functions):**
    * Filtered regular rounds (`create_regular_episodes_df`).
    * Combined Question & Answer text.
    * Derived 3-level difficulty from dollar value.
    * Standard text cleaning (lowercase, punctuation, numbers, stopwords).
3. **Topic Modeling (NMF):**
    * TF-IDF matrix (Terms x Documents).
    * Evaluated k=7-15 topics via residuals -> Chose k=13.
    * Interpreted topics using top words/word clouds.
4. **Difficulty Prediction:**
    * 10% stratified sample.
    * Train (70%) / Test (30%) split.
    * Binary TF-IDF features (presence/absence).
    * Naive Bayes classifier (`e1071`).
    * Evaluated using `caret::confusionMatrix` (Accuracy, Kappa).

---

## Slide 4: Key Result 1: Latent Topics (NMF)

* NMF with k=13 identified interpretable topics.
* **Example: Topic 1 (U.S. Politics/Govt)**
  * ![Topic 1 Word Cloud](./images/results_images/topic_1_wordcloud.png)
  * *(Briefly mention other topic examples: Geography, Arts/Culture, Science)*
* **Takeaway:** NMF effectively clustered clues into meaningful thematic groups based on vocabulary.

---

## Slide 5: Key Result 2: Difficulty Prediction

* **Model:** Naive Bayes using binary word presence.
* **Result:** ~52% Accuracy on 3-class prediction (Easy, Average, Hard).
  * (Baseline = 33% random chance)
* **Confusion Matrix Summary:** Better than chance, but modest performance (Kappa ~0.19). Struggled most with distinguishing easy vs. hard.
  * *(Optionally show a simplified confusion matrix or just key metrics)*
* **Plot:** Average Word Count vs. Difficulty
  * ![Question Word Count Plot](./images/eda_images/Question_Word_Count_counts_bar.png)
  * *(Shows only a weak trend - length slightly increases with difficulty)*
* **Takeaway:** Text *alone* (as simple features) is a weak predictor of Jeopardy! difficulty.

---

## Slide 6: Discussion & Limitations

* **Why modest accuracy?**
  * Difficulty is complex: Obscurity, wordplay, reasoning > simple word usage.
  * Simple features (binary bag-of-words) miss nuance.
  * Naive Bayes is a simple model.
  * Difficulty proxy (dollar value) is imperfect.
* **NMF Success:** Topic modeling effectively captured thematic structure.
* **Limitations:** Sample size for supervised model, simple feature set, baseline model used.

---

## Slide 7: Conclusion & Future Work

* **Conclusion:** Successfully applied NMF & classification in R. Found interpretable topics but text features alone are weak predictors of difficulty.
* **Future Directions:**
  * More complex features (n-grams, embeddings).
  * Advanced models (SVM, RF, XGBoost) & Hyperparameter tuning.
  * Incorporate NMF topics or other metadata as features.
  * Temporal analysis (changes over seasons).
* **Thank You / Questions?**
* **GitHub Repo:** <https://github.com/Naalu/Jeopardy_nlp>
